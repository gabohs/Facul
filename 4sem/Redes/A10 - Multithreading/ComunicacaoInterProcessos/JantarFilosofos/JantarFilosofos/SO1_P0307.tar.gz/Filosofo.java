/*
 * Filosofo.java
 *
 * Created on 16 de Abril de 2007, 10:48
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

import java.util.*;

/**
 *
 * @author adario
 */
public class Filosofo extends Thread {
   public static enum Estados {PENSANDO, COMENDO, FAMINTO};
   
   private static int numfilosofos = 0;
   
   private Garfo esquerda, direita;
   private String nome;
   private int ID;
   private Estados meuEstado;
   
   /** Creates a new instance of Filosofo */
   public Filosofo(Garfo esquerda, Garfo direita, String nome) {
      this.esquerda = esquerda;
      this.direita = direita;
      this.nome = nome;
      meuEstado = Estados.PENSANDO;
   }
   
   public Filosofo(Garfo esquerda, Garfo direita) {
      this(esquerda, direita, "");
   }
   
   public void pensar() {
      setEstado(Estados.PENSANDO);
      System.out.println(nome + " pensando... ");
      try {
         this.sleep(5000);
      } catch (InterruptedException e) {
      }
   }
   
   public void comer() {
      setEstado(Estados.COMENDO);
      System.out.println(nome + " comendo!!! ");
      try {
         this.sleep(5000);
      } catch (InterruptedException e) {
      }
   }
   
   public void pegaGarfos() {
      setEstado(Estados.FAMINTO);
      try {
         direita.pegar();
         esquerda.pegar();
      } catch (InterruptedException e) {}
   }
   
   public void deixaGarfos() {
      direita.largar();
      esquerda.largar();
   }
   
   public static int numConvidados() {
      return numfilosofos;
   }
   
   public Estados getEstado() {
      return this.meuEstado;
   }
   
   private void setEstado(Estados e) {
      this.meuEstado = e;
   }
   
   public void run() {
      while(true) {
         pensar();
         pegaGarfos();
         comer();
         deixaGarfos();
      }
   }
}
