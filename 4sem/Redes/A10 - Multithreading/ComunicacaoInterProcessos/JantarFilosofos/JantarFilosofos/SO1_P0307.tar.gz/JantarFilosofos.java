/*
 * JantarFilosofos.java
 *
 * Created on 16 de Abril de 2007, 10:48
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

import java.util.ArrayList;
/**
 *
 * @author adario
 */
public class JantarFilosofos {
   
   /** Creates a new instance of JantarFilosofos */
   public JantarFilosofos() {
   }
   
   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) {
      final int convidados = 5;
      String nomes[] = {"Danton", "Robespierre","Socrates", "Platao", "Aristoteles" };
      ArrayList<Garfo> garfos = new ArrayList();
      for(int i = 0; i < convidados; i++)
         garfos.add(i, new Garfo() );
      
      ArrayList<Filosofo> filosofos = new ArrayList();
      int esq, dir;
      for(int i = 0; i < convidados; i++) {
         if(i % 2 == 0) {
            esq = (i + 1) % convidados;
            dir = i % convidados;
         } else {
            dir = (i + 1) % convidados;
            esq = i % convidados;
         }
         System.out.println(nomes[i] + " com esquerda " + esq + " e direita " + dir);
         filosofos.add(i, new Filosofo(garfos.get(esq), garfos.get(dir),
               nomes[i]));
      }
      
      for(int i = 0; i < convidados; i++)
         filosofos.get(i).start();
   }
}
