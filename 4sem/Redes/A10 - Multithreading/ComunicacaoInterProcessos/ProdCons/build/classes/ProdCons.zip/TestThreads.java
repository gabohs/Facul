import java.io.*;

public class TestThreads {
   public static void main(String[] args) {
      LimitedLineBuffer meuBuffer = new LimitedLineBuffer(10);

      Produtor P1 = new Produtor(meuBuffer);
      Consumidor C1 = new Consumidor(meuBuffer);
      Thread tp = new Thread(P1, "Produtor de linhas");
      Thread tc = new Thread(C1, "Consumidor de Linhas");
      
      try {
         tp.start();
         tc.start();
         tp.join();
      } catch (InterruptedException e) {
         P1.stopRunning();
         tc.interrupt();
         e.printStackTrace();
      } finally {
         C1.stopRunning();
         tc.interrupt();
      }
      return;
   }
}